package com.denis.dis

import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.net.URISyntaxException

class SocketManager {
    companion object {
        private const val TAG = "DIS_Socket"
    }

    private var socket: Socket? = null
    private var isConnected = false

    // Подключение
    fun connect(serverUrl: String, onConnected: (() -> Unit)? = null) {
        try {
            val options = IO.Options()
            options.reconnection = true
            options.timeout = 10000
            options.transports = arrayOf("websocket", "polling")

            val url = if (serverUrl.startsWith("http")) serverUrl else "http://$serverUrl"

            socket = IO.socket(url, options)

            // События
            socket?.on(Socket.EVENT_CONNECT) {
                Log.d(TAG, "✅ Подключено к серверу")
                isConnected = true
                onConnected?.invoke()
            }

            socket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
                Log.e(TAG, "❌ Ошибка подключения: ${args.joinToString()}")
                isConnected = false
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d(TAG, "🔌 Отключено от сервера")
                isConnected = false
            }

            socket?.connect()

        } catch (e: Exception) {
            Log.e(TAG, "Ошибка создания socket", e)
        }
    }

    // Регистрация
    fun register(username: String) {
        if (!isConnected) return

        val data = JSONObject().apply {
            put("username", username)
        }

        socket?.emit("register", data)
        Log.d(TAG, "📤 Регистрация: $username")
    }

    // Отправка сообщения
    fun sendMessage(text: String) {
        if (!isConnected) return

        val data = JSONObject().apply {
            put("text", text)
        }

        socket?.emit("message", data)
        Log.d(TAG, "📤 Сообщение: $text")
    }

    // Добавление слушателя событий
    fun on(event: String, listener: (Array<Any>) -> Unit) {
        socket?.on(event) { args ->
            listener(args)
        }
    }

    // Отключение
    fun disconnect() {
        socket?.disconnect()
        socket?.off()
        isConnected = false
        Log.d(TAG, "🔌 Принудительное отключение")
    }

    fun isConnected(): Boolean = isConnected
}