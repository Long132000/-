package com.denis.dis

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvStatusMessage: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvBinaryCode: TextView
    private lateinit var etServerIp: EditText
    private lateinit var etUsername: EditText
    private lateinit var btnConnect: Button
    private lateinit var btnTest: Button
    private lateinit var statusIndicator: View

    private var socket: Socket? = null
    private var isConnected = false
    private val logMessages = mutableListOf<String>()

    companion object {
        private const val TAG = "DIS_Messenger"
        private const val MAX_LOG_LINES = 20
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация UI
        tvStatus = findViewById(R.id.tvStatus)
        tvStatusMessage = findViewById(R.id.tvStatusMessage)
        tvLog = findViewById(R.id.tvLog)
        tvBinaryCode = findViewById(R.id.tvBinaryCode)
        etServerIp = findViewById(R.id.etServerIp)
        etUsername = findViewById(R.id.etUsername)
        btnConnect = findViewById(R.id.btnConnect)
        btnTest = findViewById(R.id.btnTest)
        statusIndicator = findViewById(R.id.statusIndicator)

        // Установите ваш IP
        etServerIp.setText("10.74.224.155:3000")
        etUsername.setText("User_${(1000..9999).random()}")

        // Обработчики кнопок
        btnConnect.setOnClickListener {
            if (isConnected) {
                disconnect()
            } else {
                connect()
            }
        }

        btnTest.setOnClickListener {
            if (isConnected) {
                sendTestMessage()
            }
        }

        // Обновляем бинарный код каждые 2 секунды
        startBinaryCodeAnimation()
    }

    private fun connect() {
        val serverUrl = etServerIp.text.toString().trim()
        val username = etUsername.text.toString().trim()

        if (serverUrl.isEmpty() || username.isEmpty()) {
            addToLog("Ошибка: заполните все поля")
            updateStatus("Ошибка", "Заполните все поля", Color.RED)
            return
        }

        updateStatus("Подключение", "Подключение к серверу...", Color.YELLOW)
        addToLog("🔄 Подключение к $serverUrl")

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val options = IO.Options()
                options.reconnection = true
                options.timeout = 10000
                options.transports = arrayOf("websocket", "polling")

                val url = if (serverUrl.startsWith("http")) serverUrl else "http://$serverUrl"

                socket = IO.socket(url, options)

                // События Socket.IO
                setupSocketListeners(username)

                // Подключаемся
                socket?.connect()

            } catch (e: Exception) {
                runOnUiThread {
                    updateStatus("Ошибка", "Ошибка подключения", Color.RED)
                    addToLog("❌ Ошибка: ${e.message}")
                    Log.e(TAG, "Connection error", e)
                }
            }
        }
    }

    private fun setupSocketListeners(username: String) {
        socket?.on(Socket.EVENT_CONNECT) {
            runOnUiThread {
                updateStatus("Подключено", "Регистрация пользователя...", Color.GREEN)
                addToLog("✅ Подключено к серверу")
                isConnected = true
                btnConnect.text = "DISCONNECT"
                btnTest.isEnabled = true

                // Регистрируем пользователя
                registerUser(username)
            }
        }

        socket?.on(Socket.EVENT_CONNECT_ERROR) { args ->
            runOnUiThread {
                updateStatus("Ошибка", "Ошибка подключения", Color.RED)
                val error = args.joinToString(", ")
                addToLog("❌ Ошибка подключения: $error")
            }
        }

        socket?.on(Socket.EVENT_DISCONNECT) {
            runOnUiThread {
                updateStatus("Отключено", "Соединение разорвано", Color.RED)
                addToLog("🔌 Отключено от сервера")
                isConnected = false
                btnConnect.text = "CONNECT"
                btnTest.isEnabled = false
            }
        }

        socket?.on("system") { args ->
            runOnUiThread {
                try {
                    val data = args[0] as JSONObject
                    val message = data.getString("message")
                    addToLog("📢 Система: $message")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing system message", e)
                }
            }
        }

        socket?.on("registered") { args ->
            runOnUiThread {
                try {
                    val data = args[0] as JSONObject
                    val username = data.getString("username")
                    updateStatus("Подключено", "Зарегистрирован: $username", Color.GREEN)
                    addToLog("👤 Зарегистрирован как: $username")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing registered message", e)
                }
            }
        }

        socket?.on("new_message") { args ->
            runOnUiThread {
                try {
                    val data = args[0] as JSONObject
                    val from = data.getString("username")
                    val text = data.getString("text")
                    addToLog("📨 $from: $text")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing new_message", e)
                }
            }
        }

        socket?.on("user_connected") { args ->
            runOnUiThread {
                try {
                    val data = args[0] as JSONObject
                    val username = data.getString("username")
                    addToLog("👥 $username подключился")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing user_connected", e)
                }
            }
        }

        socket?.on("user_disconnected") { args ->
            runOnUiThread {
                try {
                    val data = args[0] as JSONObject
                    val username = data.getString("username")
                    addToLog("👥 $username отключился")
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing user_disconnected", e)
                }
            }
        }
    }

    private fun registerUser(username: String) {
        val data = JSONObject()
        data.put("username", username)
        socket?.emit("register", data)
        addToLog("📤 Регистрация: $username")
    }

    private fun sendTestMessage() {
        val text = "Тестовое сообщение от Android"
        val data = JSONObject()
        data.put("text", text)
        socket?.emit("message", data)
        addToLog("📤 Отправлено: $text")
    }

    private fun disconnect() {
        socket?.disconnect()
        socket?.off()
        isConnected = false
        updateStatus("Отключено", "Соединение закрыто", Color.RED)
        btnConnect.text = "CONNECT"
        btnTest.isEnabled = false
        addToLog("🔌 Принудительное отключение")
    }

    private fun updateStatus(status: String, message: String, color: Int) {
        tvStatus.text = "STATUS: $status"
        tvStatusMessage.text = message
        tvStatusMessage.setTextColor(color)

        // Обновляем индикатор
        statusIndicator.setBackgroundResource(
            when {
                color == Color.GREEN -> R.drawable.circle_green
                color == Color.YELLOW -> R.drawable.circle_yellow
                else -> R.drawable.circle_red
            }
        )
    }

    private fun addToLog(message: String) {
        val timestamp = Calendar.getInstance().get(Calendar.SECOND)
        val logMessage = "[$timestamp] $message"

        logMessages.add(logMessage)
        if (logMessages.size > MAX_LOG_LINES) {
            logMessages.removeFirst()
        }

        tvLog.text = logMessages.joinToString("\n")

        // Прокручиваем вниз
        tvLog.post {
            val scrollAmount = tvLog.layout.getLineTop(tvLog.lineCount) - tvLog.height
            if (scrollAmount > 0) {
                tvLog.scrollTo(0, scrollAmount)
            }
        }

        Log.d(TAG, message)
    }

    private fun startBinaryCodeAnimation() {
        Thread {
            while (true) {
                Thread.sleep(2000)
                runOnUiThread {
                    updateBinaryCode()
                }
            }
        }.start()
    }

    private fun updateBinaryCode() {
        val binary = generateBinaryCode()
        tvBinaryCode.text = binary
    }

    private fun generateBinaryCode(): String {
        return (1..6).joinToString("   ") {
            (1..8).joinToString("") { if (Math.random() > 0.5) "1" else "0" }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
    }
}