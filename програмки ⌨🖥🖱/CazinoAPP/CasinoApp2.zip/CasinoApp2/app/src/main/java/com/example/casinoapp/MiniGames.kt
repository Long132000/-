package com.example.casinoapp

import kotlin.random.Random

object MiniGames {

    // Игра в кости
    fun playDice(bet: Double): Double {
        val playerRoll = Random.nextInt(1, 7) + Random.nextInt(1, 7) // 2 кубика
        val casinoRoll = Random.nextInt(1, 7) + Random.nextInt(1, 7)

        return when {
            playerRoll > casinoRoll -> bet * 2.0 // Выигрыш 2x
            playerRoll == casinoRoll -> bet // Ничья - возврат ставки
            else -> 0.0 // Проигрыш
        }
    }

    // Слот-машина
    fun playSlots(bet: Double): Pair<Double, Triple<Int, Int, Int>> {
        val reels = Triple(
            Random.nextInt(1, 8), // 1-7 разные символы
            Random.nextInt(1, 8),
            Random.nextInt(1, 8)
        )

        val winMultiplier = when {
            reels.first == 7 && reels.second == 7 && reels.third == 7 -> 10.0 // Джекпот
            reels.first == reels.second && reels.second == reels.third -> 5.0 // Три одинаковых
            reels.first == reels.second || reels.second == reels.third -> 2.0 // Два одинаковых
            else -> 0.0
        }

        return Pair(bet * winMultiplier, reels)
    }

    // Угадай число
    fun guessNumber(bet: Double, guess: Int): Double {
        val secret = Random.nextInt(1, 4) // 1-3
        return if (guess == secret) bet * 3.0 else 0.0
    }
}