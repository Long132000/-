package com.example.casinoapp

object AchievementSystem {
    data class Achievement(
        val id: String,
        val name: String,
        val description: String,
        val reward: Int
    )

    data class PlayerStats(
        var winCount: Int = 0,
        var totalBalance: Double = 0.0,
        var dailyStreak: Int = 0,
        var deposit: Double = 0.0,
        var allInWins: Int = 0,
        var wheelJackpots: Int = 0,
        var level: Int = 1
    )

    val ACHIEVEMENTS = listOf(
        Achievement("first_win", "Первая победа", "Выиграйте в казино первый раз", 50),
        Achievement("ten_wins", "Десять побед", "Выиграйте в казино 10 раз", 500),
        Achievement("rich", "Богач", "Накопите 100 000 копеек", 1000),
        Achievement("gambler", "Азартный игрок", "Сделайте ставку 'всё' и выиграйте", 2000),
        Achievement("daily_fan", "Постоянный клиент", "Получите ежедневный бонус 30 дней подряд", 3000),
        Achievement("deposit_king", "Король депозитов", "Накопите 1 000 000 на депозите", 5000),
        Achievement("wheel_master", "Мастер колеса", "Выиграйте джекпот на колесе фортуны", 2500),
        Achievement("level_10", "Опытный игрок", "Достигните 10 уровня", 1000),
        Achievement("level_20", "Ветеран", "Достигните 20 уровня", 2500),
        Achievement("level_30", "Легенда", "Достигните 30 уровня", 5000)
    )

    fun checkAchievement(id: String, playerData: PlayerStats, unlocked: Set<String>): Achievement? {
        if (unlocked.contains(id)) return null

        return when (id) {
            "first_win" -> if (playerData.winCount >= 1) ACHIEVEMENTS[0] else null
            "ten_wins" -> if (playerData.winCount >= 10) ACHIEVEMENTS[1] else null
            "rich" -> if (playerData.totalBalance >= 100000) ACHIEVEMENTS[2] else null
            "gambler" -> if (playerData.allInWins >= 1) ACHIEVEMENTS[3] else null
            "daily_fan" -> if (playerData.dailyStreak >= 30) ACHIEVEMENTS[4] else null
            "deposit_king" -> if (playerData.deposit >= 1000000) ACHIEVEMENTS[5] else null
            "wheel_master" -> if (playerData.wheelJackpots >= 1) ACHIEVEMENTS[6] else null
            "level_10" -> if (playerData.level >= 10) ACHIEVEMENTS[7] else null
            "level_20" -> if (playerData.level >= 20) ACHIEVEMENTS[8] else null
            "level_30" -> if (playerData.level >= 30) ACHIEVEMENTS[9] else null
            else -> null
        }
    }
}