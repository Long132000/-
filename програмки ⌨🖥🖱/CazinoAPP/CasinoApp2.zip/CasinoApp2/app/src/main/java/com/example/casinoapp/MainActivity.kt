package com.example.casinoapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    // Балансы как в боте
    private var kopecks = 100.0
    private var rubies = 0.0
    private var deposit = 0.0
    private var depositInterest = 0.0
    private var level = 1
    private var exp = 0

    // Таймеры
    private var lastDailyTime: Long = 0L
    private var lastInterestTime: Long = System.currentTimeMillis()
    private var lastBuyTime: Long = 0L
    private var lastSellTime: Long = 0L
    private var lastWheelTime: Long = 0L

    // Статистика для достижений
    private var winCount = 0
    private var loseCount = 0
    private var dailyStreak = 0
    private var allInWins = 0
    private var wheelJackpots = 0

    // Достижения и предметы
    private var unlockedAchievements = mutableSetOf<String>()
    private var purchasedItems = mutableSetOf<String>()

    // Курс обмена (как в боте)
    private var exchangeRate = 100

    // Views
    private lateinit var tvKopecks: TextView
    private lateinit var tvRubies: TextView
    private lateinit var tvDeposit: TextView
    private lateinit var tvLevel: TextView
    private lateinit var tvExp: TextView
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupClickListeners()
        loadData()
        updateExchangeRate()
        calculateInterest()
        checkAchievements()
        updateUI()
    }

    private fun initViews() {
        tvKopecks = findViewById(R.id.tvKopecks)
        tvRubies = findViewById(R.id.tvRubies)
        tvDeposit = findViewById(R.id.tvDeposit)
        tvLevel = findViewById(R.id.tvLevel)
        tvExp = findViewById(R.id.tvExp)
        tvStatus = findViewById(R.id.tvStatus)
    }

    private fun setupClickListeners() {
        findViewById<Button>(R.id.btnDaily).setOnClickListener { claimDailyBonus() }
        findViewById<Button>(R.id.btnCasino).setOnClickListener { playCasinoDialog() }
        findViewById<Button>(R.id.btnAllIn).setOnClickListener { playAllIn() }
        findViewById<Button>(R.id.btnWheel).setOnClickListener { openWheel() }
        findViewById<Button>(R.id.btnExchange).setOnClickListener { openExchange() }
        findViewById<Button>(R.id.btnBank).setOnClickListener { openBank() }
        findViewById<Button>(R.id.btnProfile).setOnClickListener { showProfile() }
        findViewById<Button>(R.id.btnClan).setOnClickListener { showMessage("🏰 Кланы скоро будут доступны!") }
        findViewById<Button>(R.id.btnDev).setOnClickListener { openDevMenu() }

        // Новые кнопки RPG сегмента
        findViewById<Button>(R.id.btnShop).setOnClickListener { openShop() }
        findViewById<Button>(R.id.btnAchievements).setOnClickListener { openAchievements() }
        findViewById<Button>(R.id.btnMiniGames).setOnClickListener { openMiniGames() }
        findViewById<Button>(R.id.btnLeaderboard).setOnClickListener { openLeaderboard() }
    }

    // ================== ОСНОВНЫЕ ФУНКЦИИ ==================

    private fun claimDailyBonus() {
        val currentTime = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000

        if (lastDailyTime > 0 && currentTime - lastDailyTime < oneDayMillis) {
            val hoursLeft = ((oneDayMillis - (currentTime - lastDailyTime)) / 3600000)
            showMessage("⏰ Бонус уже получен. Осталось $hoursLeft ч.")
            return
        }

        val yesterday = currentTime - oneDayMillis
        if (lastDailyTime > 0 && lastDailyTime >= yesterday) {
            dailyStreak++
        } else {
            dailyStreak = 1
        }

        val levelInfo = LevelSystem.getLevelInfo(level)
        var bonus = 100 + levelInfo.dailyBonus // Базовый бонус + бонус за уровень

        // Бонус от предмета
        if (purchasedItems.contains("daily_boost")) {
            bonus += 50
        }

        kopecks += bonus
        lastDailyTime = currentTime

        // Добавляем опыт
        addExperience(10)

        saveData()
        updateUI()
        checkAchievements()
        showMessage("📅 Ежедневный бонус: +$bonus копеек! Серия: $dailyStreak дней")
    }

    private fun playCasinoDialog() {
        val input = EditText(this).apply {
            hint = "Введите ставку"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎰 Казино")
            .setMessage("Шанс выигрыша 50%. При победе ×2!")
            .setView(input)
            .setPositiveButton("Играть") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playCasino(bet) else showMessage("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playCasino(bet: Double) {
        if (kopecks < bet) {
            showMessage("❌ Недостаточно копеек! Нужно: $bet, есть: $kopecks")
            return
        }

        // Добавляем опыт за игру
        addExperience((bet / 10).toInt())

        var winChance = 0.5
        // Бонус от амулета удачи
        if (purchasedItems.contains("lucky_charm")) {
            winChance = 0.55
        }

        val win = Random.nextDouble() < winChance
        if (win) {
            val winAmount = bet
            kopecks += winAmount
            winCount++
            showMessage("🎉 Победа! +$winAmount копеек!")
        } else {
            kopecks -= bet
            loseCount++
            winCount = 0
            showMessage("😢 Проигрыш... -$bet копеек")
        }

        saveData()
        updateUI()
        checkAchievements()
    }

    private fun playAllIn() {
        val totalBet = kopecks + rubies * exchangeRate + deposit
        if (totalBet <= 0) {
            showMessage("❌ Нет средств для ставки!")
            return
        }

        AlertDialog.Builder(this)
            .setTitle("💥 ALL-IN")
            .setMessage("Ставка: ${"%.2f".format(totalBet)} копеек\nШанс 33% выиграть ×3!\nПодтверждаете?")
            .setPositiveButton("ДА!") { _, _ ->
                val win = Random.nextDouble() < 0.33
                if (win) {
                    val winAmount = totalBet * 3
                    kopecks = winAmount
                    rubies = 0.0
                    deposit = 0.0
                    winCount++
                    allInWins++
                    showMessage("🔥 ДЖЕКПОТ! +${"%.2f".format(winAmount)} копеек!")
                } else {
                    kopecks = 0.0
                    rubies = 0.0
                    deposit = 0.0
                    winCount = 0
                    showMessage("💀 Проигрыш! Потеряно всё!")
                }
                saveData()
                updateUI()
                checkAchievements()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun openWheel() {
        val currentTime = System.currentTimeMillis()
        val twoHoursMillis = 2 * 60 * 60 * 1000

        if (lastWheelTime > 0 && currentTime - lastWheelTime < twoHoursMillis) {
            val timeLeft = lastWheelTime + twoHoursMillis - currentTime
            val minutesLeft = timeLeft / (60 * 1000)
            val hoursLeft = minutesLeft / 60
            val remainingMinutes = minutesLeft % 60

            showMessage("❌ Колесо можно крутить раз в 2 часа!\nСледующая попытка через: ${hoursLeft.toInt()}ч ${remainingMinutes.toInt()}м")
            return
        }

        val intent = Intent(this, WheelActivity::class.java)
        intent.putExtra("kopecks", kopecks)
        intent.putExtra("lastWheelTime", lastWheelTime)
        startActivityForResult(intent, 1)
    }

    // ================== НОВЫЕ RPG ФУНКЦИИ ==================

    private fun openShop() {
        val intent = Intent(this, ShopActivity::class.java)
        intent.putExtra("kopecks", kopecks)
        startActivityForResult(intent, 2)
    }

    private fun openAchievements() {
        val intent = Intent(this, AchievementsActivity::class.java)
        intent.putExtra("unlockedAchievements", unlockedAchievements.toTypedArray())
        startActivity(intent)
    }

    private fun openMiniGames() {
        val intent = Intent(this, MiniGamesActivity::class.java)
        intent.putExtra("kopecks", kopecks)
        startActivityForResult(intent, 3)
    }

    private fun openLeaderboard() {
        val intent = Intent(this, LeaderboardActivity::class.java)
        startActivity(intent)
    }

    // ================== СИСТЕМА УРОВНЕЙ ==================

    private fun addExperience(amount: Int) {
        // Бонус от предмета
        var expGain = amount
        if (purchasedItems.contains("exp_boost")) {
            expGain = (amount * 1.2).toInt()
        }

        exp += expGain

        val currentLevelInfo = LevelSystem.getLevelInfo(level)
        val nextLevelInfo = if (level < LevelSystem.LEVELS.size) LevelSystem.getLevelInfo(level + 1) else null

        if (nextLevelInfo != null && exp >= nextLevelInfo.expRequired) {
            level++
            showMessage("🎉 Новый уровень! Теперь у вас $level уровень!\n" +
                    "💎 +${nextLevelInfo.depositBonus * 100}% к депозиту\n" +
                    "🎁 +${nextLevelInfo.dailyBonus} к ежедневному бонусу")
        }

        saveData()
        updateUI()
        checkAchievements()
    }

    // ================== СИСТЕМА ДОСТИЖЕНИЙ ==================

    private fun checkAchievements() {
        val playerStats = AchievementSystem.PlayerStats(
            winCount = winCount,
            totalBalance = kopecks + rubies * exchangeRate + deposit + depositInterest,
            dailyStreak = dailyStreak,
            deposit = deposit,
            allInWins = allInWins,
            wheelJackpots = wheelJackpots,
            level = level
        )

        AchievementSystem.ACHIEVEMENTS.forEach { achievement ->
            val newAchievement = AchievementSystem.checkAchievement(achievement.id, playerStats, unlockedAchievements)
            if (newAchievement != null) {
                unlockedAchievements.add(achievement.id)
                kopecks += achievement.reward
                showMessage("🏆 Достижение: ${achievement.name}!\n" +
                        "${achievement.description}\n" +
                        "🎁 Награда: ${achievement.reward} копеек!")
                saveData()
                updateUI()
            }
        }
    }

    // ================== ОСТАЛЬНЫЕ ФУНКЦИИ (БАНК, ОБМЕН и т.д.) ==================

    private fun openExchange() {
        val options = arrayOf("💵 Купить рубии", "💰 Продать рубии", "📊 Текущий курс")

        AlertDialog.Builder(this)
            .setTitle("💱 Обмен валюты")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> buyRubiesDialog()
                    1 -> sellRubiesDialog()
                    2 -> showMessage("📊 Курс: 1 рубий = $exchangeRate копеек")
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun buyRubiesDialog() {
        val currentTime = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000

        if (lastBuyTime > 0 && currentTime - lastBuyTime < oneDayMillis) {
            showMessage("❌ Покупать рубии можно только 1 раз в день!")
            return
        }

        val input = EditText(this).apply {
            hint = "Сколько рубиев купить?"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("💵 Покупка рубиев")
            .setMessage("Курс: 1 рубий = $exchangeRate копеек")
            .setView(input)
            .setPositiveButton("Купить") { _, _ ->
                val amount = input.text.toString().toIntOrNull() ?: 0
                if (amount > 0) buyRubies(amount) else showMessage("Введите корректное количество!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun buyRubies(amount: Int) {
        var actualExchangeRate = exchangeRate
        // Бонус от предмета
        if (purchasedItems.contains("ruby_boost")) {
            actualExchangeRate = (exchangeRate * 1.1).toInt()
        }

        val totalCost = amount * actualExchangeRate
        if (kopecks < totalCost) {
            showMessage("❌ Недостаточно копеек! Нужно: $totalCost")
            return
        }

        kopecks -= totalCost
        rubies += amount.toDouble()
        lastBuyTime = System.currentTimeMillis()

        saveData()
        updateUI()
        showMessage("✅ Куплено $amount рубиев за $totalCost копеек!")
    }

    private fun sellRubiesDialog() {
        val currentTime = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000

        if (lastSellTime > 0 && currentTime - lastSellTime < oneDayMillis) {
            showMessage("❌ Продавать рубии можно только 1 раз в день!")
            return
        }

        val input = EditText(this).apply {
            hint = "Сколько рубиев продать?"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("💰 Продажа рубиев")
            .setMessage("Курс: 1 рубий = $exchangeRate копеек\nДоступно: ${rubies.toInt()}")
            .setView(input)
            .setPositiveButton("Продать") { _, _ ->
                val amount = input.text.toString().toIntOrNull() ?: 0
                if (amount > 0) sellRubies(amount) else showMessage("Введите корректное количество!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun sellRubies(amount: Int) {
        if (rubies < amount) {
            showMessage("❌ Недостаточно рубиев! Доступно: ${rubies.toInt()}")
            return
        }

        val income = amount * exchangeRate
        kopecks += income
        rubies -= amount.toDouble()
        lastSellTime = System.currentTimeMillis()

        saveData()
        updateUI()
        showMessage("✅ Продано $amount рубиев за $income копеек!")
    }

    private fun openBank() {
        val options = arrayOf("🏦 Положить на депозит", "💰 Снять с депозита", "💸 Снять проценты", "📊 Информация")

        AlertDialog.Builder(this)
            .setTitle("🏦 Банк")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> depositDialog()
                    1 -> withdrawDialog()
                    2 -> withdrawInterest()
                    3 -> showBankInfo()
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun depositDialog() {
        val input = EditText(this).apply {
            hint = "Сумма для депозита"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🏦 Положить на депозит")
            .setMessage("Годовая ставка: ${(25 + level)}% + бонусы\nДоступно: ${"%.2f".format(kopecks)}")
            .setView(input)
            .setPositiveButton("Положить") { _, _ ->
                val amount = input.text.toString().toDoubleOrNull() ?: 0.0
                if (amount > 0) depositMoney(amount) else showMessage("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun depositMoney(amount: Double) {
        if (kopecks < amount) {
            showMessage("❌ Недостаточно копеек! Доступно: ${"%.2f".format(kopecks)}")
            return
        }

        calculateInterest()
        kopecks -= amount
        deposit += amount
        lastInterestTime = System.currentTimeMillis()

        saveData()
        updateUI()
        checkAchievements()
        showMessage("✅ $amount копеек переведены на депозит!")
    }

    private fun withdrawDialog() {
        val input = EditText(this).apply {
            hint = "Сумма для снятия"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("💰 Снять с депозита")
            .setMessage("На депозите: ${"%.2f".format(deposit)}")
            .setView(input)
            .setPositiveButton("Снять") { _, _ ->
                val amount = input.text.toString().toDoubleOrNull() ?: 0.0
                if (amount > 0) withdrawMoney(amount) else showMessage("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun withdrawMoney(amount: Double) {
        if (deposit < amount) {
            showMessage("❌ Недостаточно средств на депозите! Доступно: ${"%.2f".format(deposit)}")
            return
        }

        calculateInterest()
        kopecks += amount
        deposit -= amount

        saveData()
        updateUI()
        showMessage("✅ $amount копеек сняты с депозита!")
    }

    private fun withdrawInterest() {
        calculateInterest()
        if (depositInterest <= 0) {
            showMessage("❌ Нет накопленных процентов!")
            return
        }

        kopecks += depositInterest
        val interest = depositInterest
        depositInterest = 0.0

        saveData()
        updateUI()
        showMessage("✅ Сняты проценты: ${"%.2f".format(interest)} копеек!")
    }

    private fun showBankInfo() {
        calculateInterest()
        val minuteIncome = calculateMinuteIncome()

        val info = """
            🏦 Информация о депозите:
            
            💰 На депозите: ${"%.2f".format(deposit)}
            📈 Накопленные проценты: ${"%.2f".format(depositInterest)}
            💸 Доход в минуту: ${"%.4f".format(minuteIncome)}
            📊 Годовая ставка: ${(25 + level)}%
            💎 Бонус за уровень: +${level}%
            🔥 Серия побед: $winCount
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("🏦 Информация о банке")
            .setMessage(info)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showProfile() {
        calculateInterest()
        val totalBalance = kopecks + rubies * exchangeRate + deposit + depositInterest
        val levelInfo = LevelSystem.getLevelInfo(level)
        val (currentExp, neededExp) = LevelSystem.calculateLevelProgress(exp, level)

        val profile = """
            👤 Профиль игрока:
            
            💰 Копейки: ${"%.2f".format(kopecks)}
            💎 Рубии: ${"%.2f".format(rubies)}
            🏦 Депозит: ${"%.2f".format(deposit)}
            📈 Проценты: ${"%.2f".format(depositInterest)}
            💵 Общий баланс: ${"%.2f".format(totalBalance)}
            
            🎰 Побед: $winCount
            💀 Поражений: $loseCount
            📅 Серия бонусов: $dailyStreak дней
            🏅 Уровень: $level
            ⭐ Опыт: $currentExp/$neededExp
            💎 Бонус к депозиту: +${(levelInfo.depositBonus * 100).toInt()}%
            🎁 Бонус к ежедневному: +${levelInfo.dailyBonus}
            
            🏆 Достижений: ${unlockedAchievements.size}/${AchievementSystem.ACHIEVEMENTS.size}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("👤 Профиль")
            .setMessage(profile)
            .setPositiveButton("OK", null)
            .show()
    }

    // ================== СИСТЕМНЫЕ ФУНКЦИИ ==================

    private fun calculateInterest() {
        val currentTime = System.currentTimeMillis()
        val hoursPassed = (currentTime - lastInterestTime) / (1000 * 60 * 60).toDouble()

        if (hoursPassed > 0) {
            val levelInfo = LevelSystem.getLevelInfo(level)
            var annualRate = 0.25 + levelInfo.depositBonus // 25% + бонус за уровень

            // Бонус от предмета
            if (purchasedItems.contains("deposit_boost")) {
                annualRate += 0.005
            }

            val hourlyRate = annualRate / (365 * 24)
            val interest = deposit * hourlyRate * hoursPassed

            depositInterest += interest
            lastInterestTime = currentTime
            saveData()
        }
    }

    private fun calculateMinuteIncome(): Double {
        val levelInfo = LevelSystem.getLevelInfo(level)
        var annualRate = 0.25 + levelInfo.depositBonus

        if (purchasedItems.contains("deposit_boost")) {
            annualRate += 0.005
        }

        val minuteRate = annualRate / (365 * 24 * 60)
        return deposit * minuteRate
    }

    private fun updateExchangeRate() {
        exchangeRate = Random.nextInt(50, 151)
    }

    // ================== СОХРАНЕНИЕ ДАННЫХ ==================

    private fun saveData() {
        val prefs = getSharedPreferences("casino_data", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putFloat("kopecks", kopecks.toFloat())
            putFloat("rubies", rubies.toFloat())
            putFloat("deposit", deposit.toFloat())
            putFloat("depositInterest", depositInterest.toFloat())
            putInt("winCount", winCount)
            putInt("loseCount", loseCount)
            putInt("level", level)
            putInt("exp", exp)
            putInt("dailyStreak", dailyStreak)
            putInt("allInWins", allInWins)
            putInt("wheelJackpots", wheelJackpots)
            putInt("exchangeRate", exchangeRate)
            putLong("lastDailyTime", lastDailyTime)
            putLong("lastInterestTime", lastInterestTime)
            putLong("lastBuyTime", lastBuyTime)
            putLong("lastSellTime", lastSellTime)
            putLong("lastWheelTime", lastWheelTime)

            // Сохраняем достижения и предметы
            putStringSet("unlockedAchievements", unlockedAchievements)
            putStringSet("purchasedItems", purchasedItems)

            apply()
        }
    }

    private fun loadData() {
        val prefs = getSharedPreferences("casino_data", Context.MODE_PRIVATE)
        kopecks = prefs.getFloat("kopecks", 100f).toDouble()
        rubies = prefs.getFloat("rubies", 0f).toDouble()
        deposit = prefs.getFloat("deposit", 0f).toDouble()
        depositInterest = prefs.getFloat("depositInterest", 0f).toDouble()
        winCount = prefs.getInt("winCount", 0)
        loseCount = prefs.getInt("loseCount", 0)
        level = prefs.getInt("level", 1)
        exp = prefs.getInt("exp", 0)
        dailyStreak = prefs.getInt("dailyStreak", 0)
        allInWins = prefs.getInt("allInWins", 0)
        wheelJackpots = prefs.getInt("wheelJackpots", 0)
        exchangeRate = prefs.getInt("exchangeRate", 100)
        lastDailyTime = prefs.getLong("lastDailyTime", 0L)
        lastInterestTime = prefs.getLong("lastInterestTime", System.currentTimeMillis())
        lastBuyTime = prefs.getLong("lastBuyTime", 0L)
        lastSellTime = prefs.getLong("lastSellTime", 0L)
        lastWheelTime = prefs.getLong("lastWheelTime", 0L)

        // Загружаем достижения и предметы
        unlockedAchievements = prefs.getStringSet("unlockedAchievements", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        purchasedItems = prefs.getStringSet("purchasedItems", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
    }

    // ================== UI ==================

    private fun updateUI() {
        tvKopecks.text = "Копейки: ${"%.2f".format(kopecks)}"
        tvRubies.text = "Рубии: ${"%.2f".format(rubies)}"
        tvDeposit.text = "Депозит: ${"%.2f".format(deposit)}"
        tvLevel.text = "Уровень: $level"

        val (currentExp, neededExp) = LevelSystem.calculateLevelProgress(exp, level)
        tvExp.text = "Опыт: $currentExp/$neededExp"
    }

    private fun showMessage(message: String) {
        tvStatus.text = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun openDevMenu() {
        val input = EditText(this).apply {
            hint = "Введите пароль разработчика"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("⚙️ Меню разработчика")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val password = input.text.toString()
                if (password == "0712200507122005") {
                    kopecks += 1000
                    rubies += 10
                    exp += 100
                    saveData()
                    updateUI()
                    checkAchievements()
                    showMessage("💸 Добавлено 1000 копеек + 10 рубиев + 100 опыта!")
                } else {
                    showMessage("🚫 Неверный пароль")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            1 -> { // Колесо фортуны
                if (resultCode == RESULT_OK) {
                    val wonKopecks = data?.getDoubleExtra("wonKopecks", 0.0) ?: 0.0
                    lastWheelTime = data?.getLongExtra("lastWheelTime", 0L) ?: 0L
                    kopecks += wonKopecks

                    // Проверяем джекпот
                    if (wonKopecks > 1000) {
                        wheelJackpots++
                    }

                    saveData()
                    updateUI()
                    checkAchievements()
                    if (wonKopecks > 0) {
                        showMessage("🎡 Выигрыш с колеса: +${wonKopecks} копеек!")
                    }
                }
            }
            2 -> { // Магазин
                if (resultCode == RESULT_OK) {
                    val spentKopecks = data?.getDoubleExtra("spentKopecks", 0.0) ?: 0.0
                    val boughtItem = data?.getStringExtra("boughtItem")

                    kopecks -= spentKopecks
                    if (boughtItem != null) {
                        purchasedItems.add(boughtItem)
                    }

                    saveData()
                    updateUI()
                    showMessage("✅ Предмет куплен!")
                }
            }
            3 -> { // Мини-игры
                if (resultCode == RESULT_OK) {
                    val updatedBalance = data?.getDoubleExtra("updatedBalance", kopecks) ?: kopecks
                    kopecks = updatedBalance
                    saveData()
                    updateUI()
                    checkAchievements()
                }
            }
        }
    }
}