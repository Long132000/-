package com.example.casinoapp

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Балансы
    private var kopecks = 100.0
    private var rubies = 0.0
    private var deposit = 0.0
    private var level = 1

    // Ежедневный бонус
    private var lastDailyTime: Long = 0L

    // Статистика
    private var winCount = 0
    private var loseCount = 0

    // Проценты по депозиту
    private var lastInterestTime: Long = 0L

    // Views
    private lateinit var tvKopecks: TextView
    private lateinit var tvRubies: TextView
    private lateinit var tvDeposit: TextView
    private lateinit var tvLevel: TextView
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupClickListeners()
        loadData()
        updateUI()
    }

    // ================== КНОПКИ ==================

    private fun initViews() {
        tvKopecks = findViewById(R.id.tvKopecks)
        tvRubies = findViewById(R.id.tvRubies)
        tvDeposit = findViewById(R.id.tvDeposit)
        tvLevel = findViewById(R.id.tvLevel)
        tvStatus = findViewById(R.id.tvStatus)
    }

    private fun setupClickListeners() {
        findViewById<Button>(R.id.btnDaily).setOnClickListener { claimDailyBonus() }
        findViewById<Button>(R.id.btnCasino).setOnClickListener { playCasinoDialog() }
        findViewById<Button>(R.id.btnAllIn).setOnClickListener { playAllIn() }
        findViewById<Button>(R.id.btnWheel).setOnClickListener { showMessage("🎡 Колесо фортуны скоро будет доступно!") }
        findViewById<Button>(R.id.btnBank).setOnClickListener { openBank() }
        findViewById<Button>(R.id.btnProfile).setOnClickListener { showProfile() }
        findViewById<Button>(R.id.btnClan).setOnClickListener { showMessage("🏰 Кланы пока не реализованы!") }
        // Кнопка разработчика
        findViewById<Button>(R.id.btnDev).setOnClickListener { openDevMenu() }

    }

    // ================== ЛОГИКА ==================

    private fun claimDailyBonus() {
        val currentTime = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000

        if (currentTime - lastDailyTime < oneDayMillis) {
            val hoursLeft = ((oneDayMillis - (currentTime - lastDailyTime)) / 3600000)
            showMessage("⏰ Бонус уже получен. Осталось $hoursLeft ч.")
            return
        }

        val bonus = 100.0
        kopecks += bonus
        lastDailyTime = currentTime
        saveData()
        updateUI()
        showMessage("📅 Ежедневный бонус: +$bonus копеек!")
    }

    private fun playCasinoDialog() {
        val input = EditText(this)
        input.hint = "Введите ставку"
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER

        AlertDialog.Builder(this)
            .setTitle("🎰 Казино")
            .setMessage("Введите сумму ставки:")
            .setView(input)
            .setPositiveButton("Играть") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playCasino(bet) else showMessage("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playCasino(bet: Double) {
        if (kopecks < bet) {
            showMessage("❌ Недостаточно копеек! Нужно: $bet, есть: $kopecks")
            return
        }

        val win = Math.random() < 0.5
        if (win) {
            val winAmount = bet * 2
            kopecks += winAmount - bet
            winCount++
            showMessage("🎉 Победа! +${winAmount - bet} копеек!")
        } else {
            kopecks -= bet
            loseCount++
            showMessage("😢 Проигрыш... -$bet копеек")
        }
        saveData()
        updateUI()
    }

    private fun playAllIn() {
        val bet = kopecks
        if (bet <= 0) {
            showMessage("❌ Нет средств для ставки!")
            return
        }

        val win = Math.random() < 0.33 // шанс 1/3
        if (win) {
            val winAmount = bet * 3
            kopecks += winAmount
            showMessage("🔥 Удача! Вся ставка умножена ×3! (+$winAmount копеек)")
        } else {
            kopecks = 0.0
            showMessage("💀 Проигрыш! Потеряно всё!")
        }
        saveData()
        updateUI()
    }

    private fun openBank() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("🏦 Банк")
            .setMessage("Что хотите сделать?")
            .setPositiveButton("Положить") { _, _ -> depositMoney() }
            .setNegativeButton("Снять") { _, _ -> withdrawMoney() }
            .setNeutralButton("Закрыть", null)
            .create()
        dialog.show()
    }

    private fun depositMoney() {
        if (kopecks <= 0) {
            showMessage("Нет копеек для депозита.")
            return
        }
        deposit += kopecks
        kopecks = 0.0
        lastInterestTime = System.currentTimeMillis()
        saveData()
        updateUI()
        showMessage("💰 Положено ${"%.2f".format(deposit)} копеек на депозит.")
    }

    private fun withdrawMoney() {
        val now = System.currentTimeMillis()
        val minutesPassed = (now - lastInterestTime) / 60000
        val interestRate = 0.01 // 1% в минуту
        val interest = deposit * interestRate * minutesPassed
        deposit += interest

        kopecks += deposit
        showMessage("🏧 Снято $deposit копеек (+${"%.2f".format(interest)}%)")
        deposit = 0.0
        saveData()
        updateUI()
    }

    private fun showProfile() {
        val msg = """
            👤 Профиль игрока:
            💰 Копейки: ${"%.2f".format(kopecks)}
            💎 Рубии: ${"%.2f".format(rubies)}
            🏦 Депозит: ${"%.2f".format(deposit)}
            🎰 Побед: $winCount
            💀 Поражений: $loseCount
            🏅 Уровень: $level
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("👤 Профиль")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    // ================== СОХРАНЕНИЕ ДАННЫХ ==================

    private fun saveData() {
        val prefs = getSharedPreferences("casino_data", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putFloat("kopecks", kopecks.toFloat())
            putFloat("rubies", rubies.toFloat())
            putFloat("deposit", deposit.toFloat())
            putInt("winCount", winCount)
            putInt("loseCount", loseCount)
            putInt("level", level)
            putLong("lastDailyTime", lastDailyTime)
            putLong("lastInterestTime", lastInterestTime)
            apply()
        }
    }

    private fun loadData() {
        val prefs = getSharedPreferences("casino_data", Context.MODE_PRIVATE)
        kopecks = prefs.getFloat("kopecks", 100f).toDouble()
        rubies = prefs.getFloat("rubies", 0f).toDouble()
        deposit = prefs.getFloat("deposit", 0f).toDouble()
        winCount = prefs.getInt("winCount", 0)
        loseCount = prefs.getInt("loseCount", 0)
        level = prefs.getInt("level", 1)
        lastDailyTime = prefs.getLong("lastDailyTime", 0L)
        lastInterestTime = prefs.getLong("lastInterestTime", 0L)
    }

    // ================== UI ==================

    private fun updateUI() {
        tvKopecks.text = "Копейки: ${"%.2f".format(kopecks)}"
        tvRubies.text = "Рубии: ${"%.2f".format(rubies)}"
        tvDeposit.text = "Депозит: ${"%.2f".format(deposit)}"
        tvLevel.text = "Уровень: $level"
    }

    private fun showMessage(message: String) {
        tvStatus.text = message
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun openDevMenu() {
        val input = EditText(this)
        input.hint = "Введите пароль разработчика"
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER

        AlertDialog.Builder(this)
            .setTitle("⚙️ Меню разработчика")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val password = input.text.toString()
                if (password == "0712200507122005") {
                    kopecks += 1000
                    saveData()
                    updateUI()
                    showMessage("💸 Добавлено 1000 копеек (режим разработчика)")
                } else {
                    showMessage("🚫 Неверный пароль")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }


}
