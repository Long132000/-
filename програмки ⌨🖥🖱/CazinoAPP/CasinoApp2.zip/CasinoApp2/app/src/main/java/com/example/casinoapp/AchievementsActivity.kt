package com.example.casinoapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AchievementsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)

        val unlockedAchievements = intent.getStringArrayExtra("unlockedAchievements")?.toSet() ?: setOf()

        initViews()
        setupAchievements(unlockedAchievements)
    }

    private fun initViews() {
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun setupAchievements(unlocked: Set<String>) {
        val progress = "${unlocked.size}/${AchievementSystem.ACHIEVEMENTS.size}"
        findViewById<TextView>(R.id.tvProgress).text = "Достижения: $progress"

        val container = findViewById<LinearLayout>(R.id.achievementsContainer)

        AchievementSystem.ACHIEVEMENTS.forEach { achievement ->
            val achievementView = layoutInflater.inflate(R.layout.item_achievement_simple, container, false)

            val tvName: TextView = achievementView.findViewById(R.id.tvAchievementName)
            val tvDesc: TextView = achievementView.findViewById(R.id.tvAchievementDesc)
            val tvReward: TextView = achievementView.findViewById(R.id.tvAchievementReward)
            val tvStatus: TextView = achievementView.findViewById(R.id.tvAchievementStatus)

            tvName.text = achievement.name
            tvDesc.text = achievement.description
            tvReward.text = "Награда: ${achievement.reward} коп."

            val isUnlocked = unlocked.contains(achievement.id)
            if (isUnlocked) {
                tvStatus.text = "✅ Разблокировано"
                tvStatus.setTextColor(getColor(android.R.color.holo_green_light))
            } else {
                tvStatus.text = "❌ Не разблокировано"
                tvStatus.setTextColor(getColor(android.R.color.holo_red_light))
            }

            container.addView(achievementView)
        }
    }
}