package com.example.casinoapp

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding

class AchievementsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)

        val unlockedAchievementsArray = intent.getStringArrayExtra("unlockedAchievements") ?: emptyArray()
        val unlockedAchievements = unlockedAchievementsArray.toSet()

        setupAchievements(unlockedAchievements)
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun setupAchievements(unlocked: Set<String>) {
        val container = findViewById<LinearLayout>(R.id.achievementsContainer)
        val tvProgress = findViewById<TextView>(R.id.tvProgress)

        tvProgress.text = "Достижения: ${unlocked.size}/${AchievementSystem.ACHIEVEMENTS.size}"

        container.removeAllViews()

        AchievementSystem.ACHIEVEMENTS.forEach { achievement ->
            val achievementView = createAchievementView(achievement, unlocked.contains(achievement.id))
            container.addView(achievementView)
        }
    }

    private fun createAchievementView(achievement: AchievementSystem.Achievement, isUnlocked: Boolean): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(32)

        // Создаем фон программно
        val background = GradientDrawable()
        background.cornerRadius = 16f
        background.setColor(ContextCompat.getColor(this,
            if (isUnlocked) R.color.achievement_unlocked else R.color.achievement_locked
        ))
        layout.background = background

        val nameText = TextView(this).apply {
            text = if (isUnlocked) "✅ ${achievement.name}" else "❌ ${achievement.name}"
            setTextColor(ContextCompat.getColor(this@AchievementsActivity,
                if (isUnlocked) android.R.color.holo_green_light else android.R.color.holo_red_light))
            textSize = 18f
            setPadding(0, 0, 0, 8)
        }

        val descText = TextView(this).apply {
            text = achievement.description
            setTextColor(ContextCompat.getColor(this@AchievementsActivity, android.R.color.white))
            textSize = 14f
            setPadding(0, 0, 0, 8)
        }

        val rewardText = TextView(this).apply {
            text = "Награда: ${achievement.reward} копеек"
            setTextColor(ContextCompat.getColor(this@AchievementsActivity, android.R.color.holo_orange_light))
            textSize = 14f
        }

        layout.addView(nameText)
        layout.addView(descText)
        layout.addView(rewardText)

        return layout
    }
}