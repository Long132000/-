package com.example.casinoapp

object LevelSystem {
    data class LevelInfo(
        val level: Int,
        val expRequired: Int,
        val depositBonus: Double,
        val dailyBonus: Int
    )

    val LEVELS = listOf(
        LevelInfo(1, 0, 0.00, 0),
        LevelInfo(2, 100, 0.01, 5),
        LevelInfo(3, 300, 0.02, 10),
        LevelInfo(4, 600, 0.03, 15),
        LevelInfo(5, 1000, 0.04, 20),
        LevelInfo(6, 1500, 0.05, 25),
        LevelInfo(7, 2100, 0.06, 30),
        LevelInfo(8, 2800, 0.07, 35),
        LevelInfo(9, 3600, 0.08, 40),
        LevelInfo(10, 4500, 0.09, 50),
        LevelInfo(11, 6000, 0.10, 60),
        LevelInfo(12, 8000, 0.11, 70),
        LevelInfo(13, 10000, 0.12, 80),
        LevelInfo(14, 13000, 0.13, 90),
        LevelInfo(15, 17000, 0.14, 100),
        LevelInfo(16, 22000, 0.15, 120),
        LevelInfo(17, 28000, 0.16, 140),
        LevelInfo(18, 35000, 0.17, 160),
        LevelInfo(19, 45000, 0.18, 180),
        LevelInfo(20, 60000, 0.19, 200),
        LevelInfo(21, 80000, 0.20, 250),
        LevelInfo(22, 100000, 0.21, 300),
        LevelInfo(23, 130000, 0.22, 350),
        LevelInfo(24, 170000, 0.23, 400),
        LevelInfo(25, 220000, 0.24, 500),
        LevelInfo(26, 280000, 0.25, 600),
        LevelInfo(27, 350000, 0.26, 700),
        LevelInfo(28, 450000, 0.27, 800),
        LevelInfo(29, 600000, 0.28, 900),
        LevelInfo(30, 800000, 0.30, 1000)
    )

    fun getLevelInfo(level: Int): LevelInfo {
        return LEVELS.firstOrNull { it.level == level } ?: LEVELS.last()
    }

    fun getExpForNextLevel(currentLevel: Int): Int {
        return if (currentLevel < LEVELS.size) {
            LEVELS[currentLevel].expRequired
        } else {
            LEVELS.last().expRequired
        }
    }

    fun calculateLevelProgress(currentExp: Int, currentLevel: Int): Pair<Int, Int> {
        val currentLevelInfo = getLevelInfo(currentLevel)
        val nextLevelInfo = if (currentLevel < LEVELS.size) getLevelInfo(currentLevel + 1) else null

        return if (nextLevelInfo != null) {
            Pair(currentExp - currentLevelInfo.expRequired, nextLevelInfo.expRequired - currentLevelInfo.expRequired)
        } else {
            Pair(0, 1) // Максимальный уровень
        }
    }
}