package com.example.casinoapp

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class WheelActivity : AppCompatActivity() {

    private lateinit var wheel: ImageView
    private lateinit var spinButton: Button
    private var isSpinning = false

    private val sectors = arrayOf(
        "💰 +50 копеек",
        "💎 +1 рубин",
        "🔥 +100 копеек",
        "💀 Потеря 50 копеек",
        "🎲 Ещё один спин",
        "🏦 +10% депозит",
        "🎁 +200 копеек"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wheel)

        wheel = findViewById(R.id.wheelImage)
        spinButton = findViewById(R.id.spinButton)

        spinButton.setOnClickListener {
            if (!isSpinning) spinWheel()
        }
    }

    private fun spinWheel() {
        isSpinning = true
        val degrees = Random.nextInt(360, 360 * 5) // 1–5 оборотов
        val rotationAnimator = ObjectAnimator.ofFloat(wheel, "rotation", 0f, degrees.toFloat())
        rotationAnimator.duration = 4000
        rotationAnimator.interpolator = DecelerateInterpolator()
        rotationAnimator.start()

        rotationAnimator.addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(animation: android.animation.Animator) {}
            override fun onAnimationEnd(animation: android.animation.Animator) {
                isSpinning = false
                val index = ((degrees % 360) / (360 / sectors.size))
                val reward = sectors[index]
                Toast.makeText(applicationContext, "Результат: $reward", Toast.LENGTH_LONG).show()
                finish()
            }

            override fun onAnimationCancel(animation: android.animation.Animator) {}
            override fun onAnimationRepeat(animation: android.animation.Animator) {}
        })
    }
}
