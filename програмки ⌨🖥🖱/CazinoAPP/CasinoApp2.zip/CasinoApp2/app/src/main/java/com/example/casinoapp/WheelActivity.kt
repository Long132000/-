package com.example.casinoapp

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class WheelActivity : AppCompatActivity() {

    private lateinit var wheel: ImageView
    private lateinit var spinButton: Button
    private lateinit var tvBalance: TextView
    private var isSpinning = false

    // Призы как в телеграм боте (0x, 0.5x, 1x, 2x, 5x)
    private val prizes = arrayOf(
        Prize(0.0, "💔 Проигрыш"),
        Prize(0.5, "🍀 Маленький выигрыш"),
        Prize(1.0, "💰 Стандартный приз"),
        Prize(2.0, "🎉 Крупный выигрыш!"),
        Prize(5.0, "🔥 ДЖЕКПОТ!")
    )

    private var betAmount = 0.0
    private var currentBalance = 0.0
    private var lastSpinTime: Long = 0
    private var canSpin = true
    private var hasExtraSpins = false
    private var extraSpinsCount = 0

    data class Prize(val multiplier: Double, val text: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wheel)

        wheel = findViewById(R.id.wheelImage)
        spinButton = findViewById(R.id.spinButton)
        tvBalance = findViewById(R.id.tvBalance)

        // Получаем данные из MainActivity
        currentBalance = intent.getDoubleExtra("kopecks", 0.0)
        lastSpinTime = intent.getLongExtra("lastWheelTime", 0L)
        hasExtraSpins = intent.getBooleanExtra("hasExtraSpins", false)
        extraSpinsCount = intent.getIntExtra("extraSpinsCount", 0)

        setupUI()
        checkSpinCooldown()
    }

    private fun setupUI() {
        tvBalance.text = "Баланс: ${"%.2f".format(currentBalance)} коп."

        spinButton.setOnClickListener {
            if (!isSpinning && canSpin) {
                showBetDialog()
            }
        }

        // Показываем подсказку о призах
        val prizeText = "Призы:\n" + prizes.joinToString("\n") { "• ${it.text} (${it.multiplier}x)" }
        Toast.makeText(this, prizeText, Toast.LENGTH_LONG).show()
    }

    private fun checkSpinCooldown() {
        val currentTime = System.currentTimeMillis()
        val twoHoursMillis = 2 * 60 * 60 * 1000 // 2 часа в миллисекундах

        // Если есть дополнительные вращения, то можно крутить без ограничений
        if (hasExtraSpins && extraSpinsCount > 0) {
            canSpin = true
            spinButton.isEnabled = true
            spinButton.text = "🎡 Крутить колесо (Доп. вращений: $extraSpinsCount)"
            return
        }

        if (lastSpinTime > 0 && currentTime - lastSpinTime < twoHoursMillis) {
            canSpin = false
            val timeLeft = lastSpinTime + twoHoursMillis - currentTime
            val minutesLeft = timeLeft / (60 * 1000)
            val hoursLeft = minutesLeft / 60
            val remainingMinutes = minutesLeft % 60

            spinButton.isEnabled = false
            spinButton.text = "⏳ Доступно через: ${hoursLeft.toInt()}ч ${remainingMinutes.toInt()}м"

            Toast.makeText(this,
                "❌ Колесо можно крутить раз в 2 часа!\nСледующая попытка через: ${hoursLeft.toInt()}ч ${remainingMinutes.toInt()}м",
                Toast.LENGTH_LONG
            ).show()
        } else {
            canSpin = true
            spinButton.isEnabled = true
            spinButton.text = "🎡 Крутить колесо"
        }
    }

    private fun showBetDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Введите ставку"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        val message = buildString {
            append("Доступно: ${"%.2f".format(currentBalance)} копеек\n\n")
            append("Призы:\n💔 0x\n🍀 0.5x\n💰 1x\n🎉 2x\n🔥 5x!")
            if (hasExtraSpins && extraSpinsCount > 0) {
                append("\n\n🎡 У вас есть $extraSpinsCount дополнительных вращений!")
            }
        }

        AlertDialog.Builder(this)
            .setTitle("🎡 Колесо фортуны")
            .setMessage(message)
            .setView(input)
            .setPositiveButton("Поставить") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0 && bet <= currentBalance) {
                    betAmount = bet
                    spinButton.isEnabled = false
                    startWheelSpin()
                } else {
                    Toast.makeText(this, "❌ Неверная ставка!", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun startWheelSpin() {
        if (isSpinning) return

        isSpinning = true

        // Случайный приз как в боте
        val prize = prizes.random()
        val winAmount = betAmount * prize.multiplier

        // Анимация вращения (2-5 полных оборотов + позиция приза)
        val baseRotation = 360 * (2 + Random.nextInt(3)) // 2-4 полных оборота
        val sectorAngle = 360.0 / prizes.size
        val prizeIndex = prizes.indexOf(prize)
        val prizePosition = (prizeIndex * sectorAngle + sectorAngle / 2).toFloat()
        val extraRotation = 360 - (baseRotation % 360) + prizePosition

        val totalRotation = baseRotation + extraRotation

        val rotationAnimator = ObjectAnimator.ofFloat(wheel, "rotation", 0f, totalRotation.toFloat())
        rotationAnimator.duration = 4000
        rotationAnimator.interpolator = DecelerateInterpolator()
        rotationAnimator.start()

        rotationAnimator.addListener(object : android.animation.Animator.AnimatorListener {
            override fun onAnimationStart(animation: android.animation.Animator) {}

            override fun onAnimationEnd(animation: android.animation.Animator) {
                isSpinning = false

                // Определяем, использовали ли мы дополнительное вращение
                val usedExtraSpin = hasExtraSpins && extraSpinsCount > 0

                // Если использовали дополнительное вращение, не обновляем lastSpinTime
                if (!usedExtraSpin) {
                    lastSpinTime = System.currentTimeMillis()
                }

                // Показываем результат
                val resultMessage = buildString {
                    append("🎡 Колесо фортуны:\n")
                    append("${prize.text}\n")
                    append(if (winAmount > 0) "Выигрыш: +${winAmount.toInt()} коп." else "Выигрыш: 0 коп.")
                    if (usedExtraSpin) {
                        append("\n\nИспользовано дополнительное вращение")
                        append("\nОсталось дополнительных вращений: ${extraSpinsCount - 1}")
                    } else {
                        append("\n\n🔒 Следующее вращение через 2 часа")
                    }
                }

                AlertDialog.Builder(this@WheelActivity)
                    .setTitle("Результат")
                    .setMessage(resultMessage)
                    .setPositiveButton("OK") { _, _ ->
                        // Возвращаем результат в MainActivity
                        val resultIntent = Intent()
                        resultIntent.putExtra("wonKopecks", winAmount)
                        resultIntent.putExtra("lastWheelTime", lastSpinTime)
                        resultIntent.putExtra("usedExtraSpin", usedExtraSpin)
                        setResult(RESULT_OK, resultIntent)
                        finish()
                    }
                    .setCancelable(false)
                    .show()
            }

            override fun onAnimationCancel(animation: android.animation.Animator) {
                isSpinning = false
                spinButton.isEnabled = true
            }

            override fun onAnimationRepeat(animation: android.animation.Animator) {}
        })
    }
}