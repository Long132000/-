package com.example.casinoapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val currentNickname = intent.getStringExtra("playerName") ?: "Игрок"
        val currentLevel = intent.getIntExtra("level", 1)
        val kopecks = intent.getDoubleExtra("kopecks", 0.0)
        val rubies = intent.getDoubleExtra("rubies", 0.0)

        setupProfileViews(currentNickname, currentLevel, kopecks, rubies)
    }

    private fun setupProfileViews(nickname: String, level: Int, kopecks: Double, rubies: Double) {
        val etNickname = findViewById<EditText>(R.id.etNickname)
        val tvLevel = findViewById<TextView>(R.id.tvLevel)
        val tvKopecks = findViewById<TextView>(R.id.tvKopecks)
        val tvRubies = findViewById<TextView>(R.id.tvRubies)
        val btnSave = findViewById<Button>(R.id.btnSaveProfile)
        val btnBack = findViewById<Button>(R.id.btnBack)

        etNickname.setText(nickname)
        tvLevel.text = "Уровень: $level"
        tvKopecks.text = "Копейки: ${"%.2f".format(kopecks)}"
        tvRubies.text = "Рубии: ${"%.2f".format(rubies)}"

        btnSave.setOnClickListener {
            val newNickname = etNickname.text.toString().trim()
            if (newNickname.isNotEmpty() && newNickname.length >= 3) {
                if (newNickname.length <= 20) {
                    saveProfile(newNickname)
                } else {
                    Toast.makeText(this, "❌ Никнейм не может быть длиннее 20 символов!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "❌ Введите никнейм (минимум 3 символа)!", Toast.LENGTH_SHORT).show()
            }
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun saveProfile(nickname: String) {
        val resultIntent = Intent()
        resultIntent.putExtra("newNickname", nickname)
        setResult(RESULT_OK, resultIntent)
        finish()
    }
}