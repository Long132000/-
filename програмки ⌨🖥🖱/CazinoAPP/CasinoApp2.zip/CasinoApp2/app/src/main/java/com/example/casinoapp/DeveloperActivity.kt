package com.example.casinoapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class DeveloperActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_developer)

        setupDeveloperButtons()
    }

    private fun setupDeveloperButtons() {
        // Добавить валюту
        findViewById<Button>(R.id.btnAddCurrency).setOnClickListener {
            showAddCurrencyDialog()
        }

        // Сбросить таймер колеса
        findViewById<Button>(R.id.btnResetWheel).setOnClickListener {
            showConfirmationDialog("Сбросить таймер колеса", "Вы уверены что хотите сбросить таймер колеса?") {
                val resultIntent = Intent()
                resultIntent.putExtra("action", "reset_wheel")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        // Обнулить прогресс
        findViewById<Button>(R.id.btnResetProgress).setOnClickListener {
            showResetConfirmation()
        }

        // Тестовое вращение колеса
        findViewById<Button>(R.id.btnTestWheel).setOnClickListener {
            showConfirmationDialog("Тестовое вращение", "Открыть колесо без ограничений?") {
                val resultIntent = Intent()
                resultIntent.putExtra("action", "test_wheel")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        // Добавить все предметы
        findViewById<Button>(R.id.btnAddAllItems).setOnClickListener {
            showConfirmationDialog("Добавить все предметы", "Добавить все предметы в инвентарь?") {
                val resultIntent = Intent()
                resultIntent.putExtra("action", "add_all_items")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        // Максимальный уровень
        findViewById<Button>(R.id.btnMaxLevel).setOnClickListener {
            showConfirmationDialog("Максимальный уровень", "Установить максимальный уровень (30)?") {
                val resultIntent = Intent()
                resultIntent.putExtra("action", "max_level")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }

        // Кнопка назад
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }

    private fun showAddCurrencyDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_currency, null)

        AlertDialog.Builder(this)
            .setTitle("Добавить валюту")
            .setView(dialogView)
            .setPositiveButton("Добавить") { _, _ ->
                val amountKopecks = dialogView.findViewById<EditText>(R.id.etKopecksAmount).text.toString().toDoubleOrNull() ?: 0.0
                val amountRubies = dialogView.findViewById<EditText>(R.id.etRubiesAmount).text.toString().toDoubleOrNull() ?: 0.0
                val amountExp = dialogView.findViewById<EditText>(R.id.etExpAmount).text.toString().toIntOrNull() ?: 0

                if (amountKopecks > 0 || amountRubies > 0 || amountExp > 0) {
                    val resultIntent = Intent()
                    resultIntent.putExtra("action", "add_currency")
                    resultIntent.putExtra("kopecks", amountKopecks)
                    resultIntent.putExtra("rubies", amountRubies)
                    resultIntent.putExtra("exp", amountExp)
                    setResult(RESULT_OK, resultIntent)
                    finish()
                } else {
                    Toast.makeText(this, "❌ Введите корректные значения!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showConfirmationDialog(title: String, message: String, onConfirm: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Да") { _, _ -> onConfirm() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showResetConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("СБРОС ПРОГРЕССА")
            .setMessage("ВЫ УВЕРЕНЫ? Это действие нельзя отменить!\n\nБудут сброшены:\n• Весь баланс\n• Уровень и опыт\n• Достижения\n• Предметы\n• Вся статистика")
            .setPositiveButton("ДА, СБРОСИТЬ") { _, _ ->
                val resultIntent = Intent()
                resultIntent.putExtra("action", "reset_progress")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}