package com.example.casinoapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MiniGamesActivity : AppCompatActivity() {

    private var balance = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mini_games)

        balance = intent.getDoubleExtra("kopecks", 0.0)

        initViews()
    }

    private fun initViews() {
        findViewById<TextView>(R.id.tvBalance).text = "Баланс: ${"%.2f".format(balance)} копеек"
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        // Кости
        findViewById<Button>(R.id.btnDice).setOnClickListener { playDiceGame() }

        // Слоты
        findViewById<Button>(R.id.btnSlots).setOnClickListener { playSlotsGame() }

        // Угадай число
        findViewById<Button>(R.id.btnGuess).setOnClickListener { playGuessGame() }
    }

    private fun playDiceGame() {
        val input = EditText(this).apply {
            hint = "Ставка"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎲 Игра в кости")
            .setMessage("Бросьте 2 кубика против казино. Больше сумма - победа 2x!")
            .setView(input)
            .setPositiveButton("Бросить") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playDice(bet) else showMessage("Введите ставку!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playDice(bet: Double) {
        if (balance < bet) {
            showMessage("❌ Недостаточно копеек!")
            return
        }

        val playerRoll = Random.nextInt(1, 7) + Random.nextInt(1, 7)
        val casinoRoll = Random.nextInt(1, 7) + Random.nextInt(1, 7)

        val result = when {
            playerRoll > casinoRoll -> {
                val win = bet * 2.0
                balance += win
                "🎉 Победа! Вы: $playerRoll vs Казино: $casinoRoll\n+${win} копеек!"
            }
            playerRoll == casinoRoll -> {
                "🤝 Ничья! Вы: $playerRoll vs Казино: $casinoRoll\nСтавка возвращена!"
            }
            else -> {
                balance -= bet
                "😢 Проигрыш! Вы: $playerRoll vs Казино: $casinoRoll\n-$bet копеек!"
            }
        }

        updateBalance()
        showMessage(result)
    }

    private fun playSlotsGame() {
        val input = EditText(this).apply {
            hint = "Ставка"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎰 Слот-машина")
            .setMessage("3 одинаковых = 5x, 2 одинаковых = 2x, 777 = 10x!")
            .setView(input)
            .setPositiveButton("Крутить") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playSlots(bet) else showMessage("Введите ставку!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playSlots(bet: Double) {
        if (balance < bet) {
            showMessage("❌ Недостаточно копеек!")
            return
        }

        val symbols = listOf("🍒", "🍋", "🍊", "🍇", "🔔", "💎", "7️⃣")
        val reels = List(3) { symbols.random() }

        val winMultiplier = when {
            reels.all { it == "7️⃣" } -> 10.0 // Джекпот
            reels[0] == reels[1] && reels[1] == reels[2] -> 5.0 // Три одинаковых
            reels[0] == reels[1] || reels[1] == reels[2] -> 2.0 // Два одинаковых
            else -> 0.0
        }

        val winAmount = bet * winMultiplier
        balance += winAmount - bet

        val result = if (winAmount > 0) {
            "🎉 ${reels.joinToString(" ")}\nВыигрыш: +${winAmount} копеек!"
        } else {
            balance -= bet
            "😢 ${reels.joinToString(" ")}\nПроигрыш: -$bet копеек!"
        }

        updateBalance()
        showMessage(result)
    }

    private fun playGuessGame() {
        val input = EditText(this).apply {
            hint = "Ставка"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎯 Угадай число")
            .setMessage("Угадайте число от 1 до 3. Приз: 3x ставки!")
            .setView(input)
            .setPositiveButton("Играть") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playGuess(bet) else showMessage("Введите ставку!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playGuess(bet: Double) {
        if (balance < bet) {
            showMessage("❌ Недостаточно копеек!")
            return
        }

        val options = arrayOf("1", "2", "3")
        AlertDialog.Builder(this)
            .setTitle("🎯 Выберите число (1-3)")
            .setItems(options) { _, which ->
                val guess = which + 1
                val secret = Random.nextInt(1, 4)

                if (guess == secret) {
                    val win = bet * 3.0
                    balance += win
                    showMessage("🎉 Угадал! Загадано: $secret\n+$win копеек!")
                } else {
                    balance -= bet
                    showMessage("😢 Не угадал! Загадано: $secret\n-$bet копеек!")
                }
                updateBalance()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun updateBalance() {
        findViewById<TextView>(R.id.tvBalance).text = "Баланс: ${"%.2f".format(balance)} копеек"

        // Сохраняем результат
        val resultIntent = intent
        resultIntent.putExtra("updatedBalance", balance)
        setResult(RESULT_OK, resultIntent)
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}