package com.example.casinoapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MiniGamesActivity : AppCompatActivity() {

    private var currentBalance = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mini_games)

        currentBalance = intent.getDoubleExtra("kopecks", 0.0)
        updateBalanceDisplay()

        setupGameButtons()
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun setupGameButtons() {
        // Игра в кости
        findViewById<Button>(R.id.btnDice).setOnClickListener {
            showDiceGameDialog()
        }

        // Слот-машина
        findViewById<Button>(R.id.btnSlots).setOnClickListener {
            showSlotsGameDialog()
        }

        // Угадай число
        findViewById<Button>(R.id.btnGuess).setOnClickListener {
            showGuessGameDialog()
        }
    }

    private fun showDiceGameDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Введите ставку"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎲 Игра в кости")
            .setMessage("Бросьте кубик! Если выпадет 4, 5 или 6 - выигрыш ×2!")
            .setView(input)
            .setPositiveButton("Бросить") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playDiceGame(bet) else showToast("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playDiceGame(bet: Double) {
        if (currentBalance < bet) {
            showToast("❌ Недостаточно копеек!")
            return
        }

        val diceRoll = Random.nextInt(1, 7)

        if (diceRoll >= 4) {
            val winAmount = bet
            currentBalance += winAmount
            showToast("🎉 Выпало $diceRoll! Победа! +$winAmount копеек")
        } else {
            currentBalance -= bet
            showToast("😢 Выпало $diceRoll... Проигрыш -$bet копеек")
        }

        updateBalanceDisplay()
        saveResult()
    }

    private fun showSlotsGameDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Введите ставку"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎰 Слот-машина")
            .setMessage("3 одинаковых символа = ×5 выигрыш!\n2 одинаковых символа = ×2 выигрыш!")
            .setView(input)
            .setPositiveButton("Крутить") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playSlotsGame(bet) else showToast("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playSlotsGame(bet: Double) {
        if (currentBalance < bet) {
            showToast("❌ Недостаточно копеек!")
            return
        }

        val symbols = arrayOf("🍒", "🍋", "🍊", "⭐", "🔔", "7️⃣")
        val result = Array(3) { symbols.random() }

        val winMultiplier = when {
            result[0] == result[1] && result[1] == result[2] -> 5.0 // 3 одинаковых
            result[0] == result[1] || result[1] == result[2] || result[0] == result[2] -> 2.0 // 2 одинаковых
            else -> 0.0
        }

        val winAmount = bet * winMultiplier

        if (winAmount > 0) {
            currentBalance += winAmount
            showToast("${result.joinToString(" ")}\n🎉 Выигрыш! +$winAmount копеек")
        } else {
            currentBalance -= bet
            showToast("${result.joinToString(" ")}\n😢 Проигрыш -$bet копеек")
        }

        updateBalanceDisplay()
        saveResult()
    }

    private fun showGuessGameDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Введите ставку"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎯 Угадай число")
            .setMessage("Угадайте число от 1 до 5 и выиграйте ×3!")
            .setView(input)
            .setPositiveButton("Играть") { _, _ ->
                val bet = input.text.toString().toDoubleOrNull() ?: 0.0
                if (bet > 0) playGuessGame(bet) else showToast("Введите корректную сумму!")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun playGuessGame(bet: Double) {
        if (currentBalance < bet) {
            showToast("❌ Недостаточно копеек!")
            return
        }

        val secretNumber = Random.nextInt(1, 6)

        val numberInput = android.widget.EditText(this).apply {
            hint = "Число от 1 до 5"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        AlertDialog.Builder(this)
            .setTitle("🎯 Угадай число")
            .setMessage("Введите число от 1 до 5:")
            .setView(numberInput)
            .setPositiveButton("Угадать") { _, _ ->
                val guess = numberInput.text.toString().toIntOrNull()
                if (guess != null && guess in 1..5) {
                    if (guess == secretNumber) {
                        val winAmount = bet * 3
                        currentBalance += winAmount
                        showToast("🎉 Правильно! Загаданное число: $secretNumber\nВыигрыш: +$winAmount копеек")
                    } else {
                        currentBalance -= bet
                        showToast("😢 Не угадали! Загаданное число: $secretNumber\nПроигрыш: -$bet копеек")
                    }
                    updateBalanceDisplay()
                    saveResult()
                } else {
                    showToast("❌ Введите число от 1 до 5!")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun updateBalanceDisplay() {
        findViewById<TextView>(R.id.tvBalance).text = "Баланс: ${"%.2f".format(currentBalance)} копеек"
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun saveResult() {
        val resultIntent = Intent()
        resultIntent.putExtra("updatedBalance", currentBalance)
        setResult(RESULT_OK, resultIntent)
    }

    override fun onBackPressed() {
        saveResult()
        super.onBackPressed()
    }
}