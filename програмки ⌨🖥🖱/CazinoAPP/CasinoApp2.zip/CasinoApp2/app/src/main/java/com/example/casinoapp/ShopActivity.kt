package com.example.casinoapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ShopActivity : AppCompatActivity() {

    private lateinit var tvBalance: TextView
    private var balance = 0.0

    data class ShopItem(
        val id: String,
        val name: String,
        val description: String,
        val price: Int,
        val type: String,
        val icon: String = "🛍️"
    )

    private val shopItems = listOf(
        ShopItem("deposit_boost", "💎 Усилитель депозита", "+0.5% к годовой ставке депозита", 5000, "permanent"),
        ShopItem("daily_boost", "📅 Усилитель бонуса", "+50 к ежедневному бонусу (30 дней)", 3000, "temporary"),
        ShopItem("wheel_spin", "🎡 Дополнительное вращение", "Дополнительный спин колеса", 1000, "consumable"),
        ShopItem("exp_boost", "🌟 Ускоритель опыта", "+20% к опыту (7 дней)", 2000, "temporary"),
        ShopItem("lucky_charm", "🍀 Амулет удачи", "+5% шанс выигрыша (7 дней)", 1500, "temporary"),
        ShopItem("ruby_boost", "💎 Бустер рубиев", "+10% к курсу обмена (7 дней)", 2000, "temporary")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)

        balance = intent.getDoubleExtra("kopecks", 0.0)
        initViews()
    }

    private fun initViews() {
        tvBalance = findViewById(R.id.tvBalance)
        tvBalance.text = "Баланс: ${"%.2f".format(balance)} копеек"

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        setupShopItems()
    }

    private fun setupShopItems() {
        val container = findViewById<LinearLayout>(R.id.shopContainer)

        shopItems.forEach { item ->
            val itemView = layoutInflater.inflate(R.layout.item_shop_simple, container, false)

            val tvName: TextView = itemView.findViewById(R.id.tvItemName)
            val tvDesc: TextView = itemView.findViewById(R.id.tvItemDescription)
            val tvPrice: TextView = itemView.findViewById(R.id.tvItemPrice)
            val btnBuy: Button = itemView.findViewById(R.id.btnBuy)

            tvName.text = item.name
            tvDesc.text = item.description
            tvPrice.text = "${item.price} коп."

            btnBuy.setOnClickListener {
                showBuyDialog(item)
            }

            container.addView(itemView)
        }
    }

    private fun showBuyDialog(item: ShopItem) {
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("${item.description}\n\nЦена: ${item.price} копеек")
            .setPositiveButton("Купить") { _, _ -> buyItem(item) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun buyItem(item: ShopItem) {
        if (balance < item.price) {
            Toast.makeText(this, "❌ Недостаточно копеек!", Toast.LENGTH_SHORT).show()
            return
        }

        balance -= item.price

        val resultIntent = Intent()
        resultIntent.putExtra("spentKopecks", item.price.toDouble())
        resultIntent.putExtra("boughtItem", item.id)
        setResult(RESULT_OK, resultIntent)

        tvBalance.text = "Баланс: ${"%.2f".format(balance)} копеек"
        Toast.makeText(this, "✅ ${item.name} куплен!", Toast.LENGTH_SHORT).show()
    }
}