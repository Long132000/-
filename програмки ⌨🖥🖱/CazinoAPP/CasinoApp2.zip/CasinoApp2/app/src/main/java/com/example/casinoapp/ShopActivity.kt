package com.example.casinoapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ShopActivity : AppCompatActivity() {

    private lateinit var tvBalance: TextView
    private lateinit var tvInventory: TextView
    private var balance = 0.0
    private val inventory = mutableMapOf<String, Int>()

    data class ShopItem(
        val id: String,
        val name: String,
        val description: String,
        val price: Int,
        val type: String, // "permanent", "temporary", "consumable", "single_use"
        val maxQuantity: Int = 1, // Максимальное количество для покупки
        val duration: Int = 0, // Длительность в днях для временных предметов
        val icon: String = "🛍️"
    )

    // Обновленный список предметов с типами
    private val shopItems = listOf(
        // PERMANENT - можно купить только один раз навсегда
        ShopItem("deposit_boost", "💎 Усилитель депозита", "+0.5% к годовой ставке депозита (навсегда)", 5000, "permanent"),
        ShopItem("lucky_charm", "🍀 Амулет удачи", "+5% шанс выигрыша (навсегда)", 10000, "permanent"),

        // TEMPORARY - можно покупать повторно после истечения срока
        ShopItem("daily_boost", "📅 Усилитель бонуса", "+50 к ежедневному бонусу (30 дней)", 3000, "temporary", duration = 30),
        ShopItem("exp_boost", "🌟 Ускоритель опыта", "+20% к опыту (7 дней)", 2000, "temporary", duration = 7),
        ShopItem("ruby_boost", "💎 Бустер рубиев", "+10% к курсу обмена (7 дней)", 2000, "temporary", duration = 7),

        // CONSUMABLE - можно покупать много раз, накапливаются
        ShopItem("wheel_spin", "🎡 Дополнительное вращение", "Дополнительный спин колеса", 1000, "consumable", maxQuantity = 10),
        ShopItem("time_machine", "⏱️ Машина времени", "Сбрасывает все таймеры действий", 2000, "consumable", maxQuantity = 5),
        ShopItem("fortune_teller", "🔮 Предсказатель", "Подсказывает ответ в викторине", 1500, "consumable", maxQuantity = 3),

        // SINGLE_USE - можно купить только один раз (не навсегда, но нельзя купить второй)
        ShopItem("starter_pack", "🎁 Стартовый набор", "1000 копеек + 5 рубиев", 500, "single_use"),
        ShopItem("treasure_map", "🗺️ Карта сокровищ", "15% шанс найти сокровище при получении бонуса", 2500, "single_use"),
        ShopItem("philosopher_stone", "🔮 Философский камень", "+15% к курсу обмена рубиев", 5000, "single_use")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop)

        balance = intent.getDoubleExtra("kopecks", 0.0)
        val inventoryData = intent.getStringExtra("inventory")
        inventoryData?.let { updateInventoryFromString(it) }

        initViews()
        updateBalanceDisplay()
        updateInventoryDisplay()
    }

    private fun initViews() {
        tvBalance = findViewById(R.id.tvBalance)
        tvInventory = findViewById(R.id.tvInventory)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        setupShopItems()
    }

    private fun updateInventoryFromString(inventoryString: String) {
        inventory.clear()
        if (inventoryString.isNotEmpty()) {
            inventoryString.split(",").forEach { item ->
                val parts = item.split(":")
                if (parts.size == 2) {
                    inventory[parts[0]] = parts[1].toInt()
                }
            }
        }
    }

    private fun updateInventoryDisplay() {
        if (inventory.isNotEmpty()) {
            val inventoryText = inventory.entries.joinToString("\n") {
                "${getItemName(it.key)}: ${it.value}"
            }
            tvInventory.text = "🎒 Ваш инвентарь:\n$inventoryText"
            tvInventory.visibility = android.view.View.VISIBLE
        } else {
            tvInventory.visibility = android.view.View.GONE
        }
    }

    private fun getItemName(itemId: String): String {
        return when (itemId) {
            "wheel_spin" -> "🎡 Доп. вращение"
            "deposit_boost" -> "💎 Усилитель депозита"
            "daily_boost" -> "📅 Усилитель бонуса"
            "exp_boost" -> "🌟 Ускоритель опыта"
            "lucky_charm" -> "🍀 Амулет удачи"
            "ruby_boost" -> "💎 Бустер рубиев"
            "time_machine" -> "⏱️ Машина времени"
            "fortune_teller" -> "🔮 Предсказатель"
            "starter_pack" -> "🎁 Стартовый набор"
            "treasure_map" -> "🗺️ Карта сокровищ"
            "philosopher_stone" -> "🔮 Философский камень"
            else -> itemId
        }
    }

    private fun setupShopItems() {
        val container = findViewById<LinearLayout>(R.id.shopContainer)
        container.removeAllViews()

        shopItems.forEach { item ->
            val itemView = layoutInflater.inflate(R.layout.item_shop_simple, container, false)

            val tvName: TextView = itemView.findViewById(R.id.tvItemName)
            val tvDesc: TextView = itemView.findViewById(R.id.tvItemDescription)
            val tvPrice: TextView = itemView.findViewById(R.id.tvItemPrice)
            val btnBuy: Button = itemView.findViewById(R.id.btnBuy)
            val tvOwned: TextView = itemView.findViewById(R.id.tvOwned) // Добавим этот TextView в макет

            tvName.text = item.name
            tvDesc.text = item.description
            tvPrice.text = "${item.price} коп."

            // Показываем сколько уже есть у игрока
            val ownedCount = inventory[item.id] ?: 0
            when (item.type) {
                "permanent" -> {
                    tvOwned.text = if (ownedCount > 0) "✅ Куплено" else "❌ Не куплено"
                    btnBuy.isEnabled = ownedCount == 0
                }
                "single_use" -> {
                    tvOwned.text = if (ownedCount > 0) "✅ Куплено" else "❌ Не куплено"
                    btnBuy.isEnabled = ownedCount == 0
                }
                "consumable" -> {
                    tvOwned.text = "В наличии: $ownedCount/${item.maxQuantity}"
                    btnBuy.isEnabled = ownedCount < item.maxQuantity
                }
                "temporary" -> {
                    tvOwned.text = if (ownedCount > 0) "⏳ Активно" else "❌ Не активно"
                    btnBuy.isEnabled = true // Можно покупать даже если активно
                }
            }

            btnBuy.setOnClickListener {
                if (btnBuy.isEnabled) {
                    showBuyDialog(item)
                }
            }

            container.addView(itemView)
        }
    }

    private fun showBuyDialog(item: ShopItem) {
        val ownedCount = inventory[item.id] ?: 0

        val message = when (item.type) {
            "permanent" -> "Этот предмет покупается один раз навсегда!"
            "single_use" -> "Этот предмет можно купить только один раз!"
            "consumable" -> "Можно купить до ${item.maxQuantity} штук. У вас: $ownedCount"
            "temporary" -> "Действует ${item.duration} дней. Можно купить снова после истечения срока."
            else -> ""
        }

        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("${item.description}\n\n$message\n\nЦена: ${item.price} копеек")
            .setPositiveButton("Купить") { _, _ -> buyItem(item) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun buyItem(item: ShopItem) {
        if (balance < item.price) {
            Toast.makeText(this, "❌ Недостаточно копеек!", Toast.LENGTH_SHORT).show()
            return
        }

        val currentCount = inventory[item.id] ?: 0

        // Проверяем ограничения по количеству
        when (item.type) {
            "permanent", "single_use" -> {
                if (currentCount > 0) {
                    Toast.makeText(this, "❌ Этот предмет уже куплен!", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            "consumable" -> {
                if (currentCount >= item.maxQuantity) {
                    Toast.makeText(this, "❌ Достигнут лимит покупок!", Toast.LENGTH_SHORT).show()
                    return
                }
            }
        }

        // Обновляем баланс
        balance -= item.price

        // Обновляем инвентарь
        inventory[item.id] = currentCount + 1

        // Возвращаем результат
        val resultIntent = Intent()
        resultIntent.putExtra("boughtItem", item.id)
        resultIntent.putExtra("itemType", item.type)
        resultIntent.putExtra("newBalance", balance)
        resultIntent.putExtra("inventory", inventoryToString())
        setResult(RESULT_OK, resultIntent)

        updateBalanceDisplay()
        updateInventoryDisplay()
        setupShopItems() // Перерисовываем предметы для обновления кнопок

        Toast.makeText(this, "✅ ${item.name} куплен!", Toast.LENGTH_SHORT).show()
    }

    private fun inventoryToString(): String {
        return inventory.entries.joinToString(",") { "${it.key}:${it.value}" }
    }

    private fun updateBalanceDisplay() {
        tvBalance.text = "Баланс: ${"%.2f".format(balance)} копеек"
    }
}