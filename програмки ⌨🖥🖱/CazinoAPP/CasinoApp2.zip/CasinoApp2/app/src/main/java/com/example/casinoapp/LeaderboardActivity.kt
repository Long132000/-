package com.example.casinoapp

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LeaderboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        initViews()
        loadLeaderboard()
    }

    private fun initViews() {
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun loadLeaderboard() {
        val prefs = getSharedPreferences("casino_data", Context.MODE_PRIVATE)
        val allData = prefs.all

        val players = mutableListOf<PlayerRank>()

        // Собираем данные всех игроков (упрощённо)
        val currentPlayer = PlayerRank(
            name = "Вы",
            kopecks = prefs.getFloat("kopecks", 0f).toDouble(),
            rubies = prefs.getFloat("rubies", 0f).toDouble(),
            deposit = prefs.getFloat("deposit", 0f).toDouble(),
            level = prefs.getInt("level", 1)
        )
        players.add(currentPlayer)

        // Добавляем тестовых игроков для демонстрации
        players.add(PlayerRank("Игрок_1", 50000.0, 100.0, 20000.0, 15))
        players.add(PlayerRank("Игрок_2", 25000.0, 50.0, 15000.0, 12))
        players.add(PlayerRank("Игрок_3", 100000.0, 200.0, 50000.0, 20))
        players.add(PlayerRank("Игрок_4", 15000.0, 30.0, 8000.0, 8))

        // Сортируем по общему балансу
        players.sortByDescending { it.totalBalance }

        displayLeaderboard(players)
    }

    private fun displayLeaderboard(players: List<PlayerRank>) {
        val container = findViewById<LinearLayout>(R.id.leaderboardContainer)
        container.removeAllViews()

        players.forEachIndexed { index, player ->
            val rankView = layoutInflater.inflate(R.layout.item_leaderboard, container, false)

            val tvRank: TextView = rankView.findViewById(R.id.tvRank)
            val tvName: TextView = rankView.findViewById(R.id.tvPlayerName)
            val tvBalance: TextView = rankView.findViewById(R.id.tvBalance)
            val tvLevel: TextView = rankView.findViewById(R.id.tvLevel)

            tvRank.text = "#${index + 1}"
            tvName.text = player.name
            tvBalance.text = "Баланс: ${"%.0f".format(player.totalBalance)}"
            tvLevel.text = "Ур. ${player.level}"

            // Выделяем текущего игрока
            if (player.name == "Вы") {
                rankView.setBackgroundColor(getColor(android.R.color.holo_blue_dark))
            }

            container.addView(rankView)
        }
    }

    data class PlayerRank(
        val name: String,
        val kopecks: Double,
        val rubies: Double,
        val deposit: Double,
        val level: Int
    ) {
        val totalBalance: Double
            get() = kopecks + rubies * 100 + deposit
    }
}