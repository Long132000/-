package com.example.casinoapp

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding

class LeaderboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        setupLeaderboard()
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun setupLeaderboard() {
        val container = findViewById<LinearLayout>(R.id.leaderboardContainer)
        container.removeAllViews()

        // Получаем данные всех игроков (в реальном приложении здесь был бы сервер)
        val players = getSamplePlayersData()

        if (players.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "📊 Рейтинг игроков пока пуст\n\nБудьте первым в топе!"
                setTextColor(ContextCompat.getColor(this@LeaderboardActivity, android.R.color.white))
                textSize = 16f
                gravity = android.view.Gravity.CENTER
                setPadding(32)
            }
            container.addView(emptyText)
            return
        }

        // Сортируем по балансу
        val sortedPlayers = players.sortedByDescending { it.balance }

        sortedPlayers.forEachIndexed { index, player ->
            val playerView = createPlayerView(player, index + 1)
            container.addView(playerView)
        }
    }

    private fun createPlayerView(player: Player, rank: Int): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL
        layout.setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent))
        layout.setPadding(16)
        layout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(0, 0, 0, 8)
        }

        // Ранг
        val rankText = TextView(this).apply {
            text = "#$rank"
            setTextColor(
                ContextCompat.getColor(this@LeaderboardActivity,
                    when (rank) {
                        1 -> android.R.color.holo_orange_light
                        2 -> android.R.color.holo_green_light
                        3 -> android.R.color.holo_blue_light
                        else -> android.R.color.white
                    }
                )
            )
            textSize = 16f
            setPadding(0, 0, 16, 0)
            layoutParams = LinearLayout.LayoutParams(60, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // Имя игрока
        val nameText = TextView(this).apply {
            text = player.name
            setTextColor(ContextCompat.getColor(this@LeaderboardActivity, android.R.color.white))
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                weight = 1f
            }
        }

        // Баланс
        val balanceText = TextView(this).apply {
            text = "${"%.0f".format(player.balance)} коп."
            setTextColor(ContextCompat.getColor(this@LeaderboardActivity, android.R.color.holo_green_light))
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                weight = 1f
            }
        }

        // Уровень
        val levelText = TextView(this).apply {
            text = "Ур. ${player.level}"
            setTextColor(ContextCompat.getColor(this@LeaderboardActivity, android.R.color.holo_blue_light))
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(80, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        layout.addView(rankText)
        layout.addView(nameText)
        layout.addView(balanceText)
        layout.addView(levelText)

        return layout
    }

    private fun getSamplePlayersData(): List<Player> {
        // В реальном приложении здесь бы загружались данные из SharedPreferences или сервера
        return listOf(
            Player("Алексей", 15420.0, 15),
            Player("Мария", 12850.0, 12),
            Player("Дмитрий", 9850.0, 10),
            Player("Анна", 7450.0, 8),
            Player("Иван", 5200.0, 6),
            Player("Вы", 100.0, 1) // Текущий игрок
        )
    }

    data class Player(
        val name: String,
        val balance: Double,
        val level: Int
    )
}