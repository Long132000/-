package com.example.lab2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView textView1;
    private TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов без избыточного приведения типов
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        Button buttonCopy = findViewById(R.id.buttonCopy);

        // Обработчики с лямбда-выражениями
        buttonAdd.setOnClickListener(v -> addStarToText());
        buttonCopy.setOnClickListener(v -> copyText());
    }

    private void addStarToText() {
        CharSequence currentText = textView1.getText();
        // Используем StringBuilder для избежания конкатенации
        StringBuilder newText = new StringBuilder();
        newText.append(currentText).append("*");
        textView1.setText(newText);
    }

    private void copyText() {
        CharSequence textFromTextView1 = textView1.getText();
        textView2.setText(textFromTextView1);
    }
}