package com.cleanplanet.simple

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Находим кнопки
        val buttonPartners = findViewById<Button>(R.id.buttonPartners)
        val buttonAddPartner = findViewById<Button>(R.id.buttonAddPartner)
        val buttonCalculator = findViewById<Button>(R.id.buttonCalculator)
        val buttonHistory = findViewById<Button>(R.id.buttonHistory)
        val buttonExport = findViewById<Button>(R.id.buttonExport)

        // Обработчики навигации
        buttonPartners.setOnClickListener {
            val intent = Intent(this, PartnersListActivity::class.java)
            startActivity(intent)
        }

        buttonAddPartner.setOnClickListener {
            val intent = Intent(this, PartnerEditActivity::class.java)
            startActivity(intent)
        }

        buttonCalculator.setOnClickListener {
            val intent = Intent(this, CalculatorActivity::class.java)
            startActivity(intent)
        }

        buttonHistory.setOnClickListener {
            val intent = Intent(this, ServiceHistoryActivity::class.java)
            startActivity(intent)
        }

        buttonExport.setOnClickListener {
            val intent = Intent(this, ExportActivity::class.java)
            startActivity(intent)
        }
    }
}