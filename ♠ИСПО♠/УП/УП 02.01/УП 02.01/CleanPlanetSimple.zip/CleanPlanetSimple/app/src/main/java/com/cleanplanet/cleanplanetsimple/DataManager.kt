package com.cleanplanet.simple

import android.content.Context
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class DataManager(private val context: Context) {

    private val partners = ArrayList<Partner>()
    private val serviceHistory = ArrayList<ServiceRecord>()

    init {
        // Инициализация тестовыми данными
        initTestData()
    }

    private fun initTestData() {
        if (partners.isEmpty()) {
            partners.addAll(listOf(
                Partner(1, "ООО Чистый Мир", "Розничный пункт", "Иванов П.С.", "+79991234567", "cleanworld@mail.ru", 8, "ул. Ленина, 15", "1234567890"),
                Partner(2, "СтиркаПрофи", "Корпоративный клиент", "Петрова А.И.", "+79992345678", "stirka@yandex.ru", 9, "пр. Мира, 28", "0987654321"),
                Partner(3, "АггрегатУслуг", "Интернет-агрегатор", "Сидоров В.К.", "+79993456789", "aggregate@gmail.com", 7, "ул. Центральная, 5", "1122334455"),
                Partner(4, "ЧистоГрад", "Розничный пункт", "Козлов Д.М.", "+79994567890", "cleanograd@mail.ru", 8, "ул. Промышленная, 10", "4455667788"),
                Partner(5, "БыстраяСтирка", "Корпоративный клиент", "Николаева С.В.", "+79995678901", "fastclean@yandex.ru", 6, "пр. Строителей, 25", "5566778899")
            ))
        }

        if (serviceHistory.isEmpty()) {
            serviceHistory.addAll(listOf(
                ServiceRecord("2024-01-15", "ООО Чистый Мир", "Стирка белья", 5, 2500.0),
                ServiceRecord("2024-01-16", "ООО Чистый Мир", "Химчистка пальто", 2, 2400.0),
                ServiceRecord("2024-01-17", "СтиркаПрофи", "Стирка белья", 10, 5000.0),
                ServiceRecord("2024-01-18", "АггрегатУслуг", "Ремонт одежды", 3, 900.0),
                ServiceRecord("2024-01-20", "ЧистоГрад", "Стирка белья", 8, 4000.0),
                ServiceRecord("2024-01-22", "БыстраяСтирка", "Химчистка куртки", 4, 4800.0)
            ))
        }
    }

    fun getPartners(): List<Partner> = partners.toList()

    fun getServiceHistory(): List<ServiceRecord> = serviceHistory.toList()

    fun addPartner(partner: Partner): Boolean {
        return try {
            val newId = if (partners.isEmpty()) 1 else partners.maxOf { it.id } + 1
            partners.add(partner.copy(id = newId))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun updatePartner(partnerId: Int, updatedPartner: Partner): Boolean {
        val index = partners.indexOfFirst { it.id == partnerId }
        return if (index != -1) {
            partners[index] = updatedPartner.copy(id = partnerId)
            true
        } else {
            false
        }
    }

    fun getPartnerById(partnerId: Int): Partner? {
        return partners.find { it.id == partnerId }
    }

    fun deletePartner(partnerId: Int): Boolean {
        return partners.removeAll { it.id == partnerId }
    }

    // Валидация email
    fun isValidEmail(email: String): Boolean {
        val emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\$"
        return email.matches(emailRegex.toRegex())
    }

    // Валидация телефона
    fun isValidPhone(phone: String): Boolean {
        val phoneRegex = "^\\+7[0-9]{10}\$"
        return phone.matches(phoneRegex.toRegex())
    }

    // Валидация рейтинга
    fun isValidRating(rating: Int): Boolean {
        return rating in 0..10
    }

    // Поиск партнеров
    fun searchPartners(query: String): List<Partner> {
        if (query.isEmpty()) return partners.toList()

        return partners.filter {
            it.name.contains(query, ignoreCase = true) ||
                    it.director.contains(query, ignoreCase = true) ||
                    it.phone.contains(query, ignoreCase = true) ||
                    it.email.contains(query, ignoreCase = true)
        }
    }

    // Фильтрация по типу
    fun filterPartnersByType(type: String): List<Partner> {
        return partners.filter { it.type == type }
    }

    // Фильтрация по рейтингу
    fun filterPartnersByMinRating(minRating: Int): List<Partner> {
        return partners.filter { it.rating >= minRating }
    }

    // Сортировка
    fun getPartnersSortedByRating(): List<Partner> {
        return partners.sortedByDescending { it.rating }
    }

    fun getPartnersSortedByName(): List<Partner> {
        return partners.sortedBy { it.name }
    }

    // Экспорт
    fun exportPartnersToCsv(): Boolean {
        return try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "partners_export_$timestamp.csv"

            val csvHeader = "ID;Наименование;Тип;Директор;Телефон;Email;Рейтинг;Адрес;ИНН\n"
            val csvContent = partners.joinToString("\n") { partner ->
                "${partner.id};${partner.name};${partner.type};${partner.director};${partner.phone};${partner.email};${partner.rating};${partner.address};${partner.inn}"
            }

            val fileContent = csvHeader + csvContent

            val file = File(context.getExternalFilesDir(null), fileName)
            FileOutputStream(file).use { fos ->
                fos.write(fileContent.toByteArray())
            }

            true
        } catch (e: Exception) {
            false
        }
    }

    // Резервное копирование
    fun createBackup(): Boolean {
        return try {
            showToast("✅ Резервная копия создана\nПартнеров: ${partners.size}\nЗаписей: ${serviceHistory.size}")
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}

data class ServiceRecord(
    val date: String,
    val partnerName: String,
    val serviceName: String,
    val quantity: Int,
    val totalPrice: Double
)