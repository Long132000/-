// document.querySelector('.Badid').addEventListener('click', function() {
//   let price = document.querySelector('.Price222').textContent;
//   document.getElementById('Price48').textContent = price;
// });

// document.querySelector('.info__headline').addEventListener('click', function() {
//     var img = document.getElementById('switchImage');
//     if (img.style.display === 'none') {
//         img.src = 'static/images/add1.png';
//         img.style.display = 'block';
//     } else {
//         img.style.display = 'none';
//     }
// });
